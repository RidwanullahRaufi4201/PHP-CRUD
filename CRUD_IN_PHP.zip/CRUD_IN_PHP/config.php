<?php

$dbconn["host"]="localhost";
$dbconn["username"]="root";
$dbconn["password"]="";
$dbconn["dbname"]="newcrud";

foreach($dbconn as$key=>$value){
    define(strtoupper($key),$value);
}

$databaseConn=mysqli_connect(HOST,USERNAME,PASSWORD,DBNAME) or die("Connection failed");

?>