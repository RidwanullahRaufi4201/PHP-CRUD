<?php
  
  require("config.php");

  if(isset($_GET["id"])){
       $userId=$_GET['id'];
       $deleteQuery="DELETE FROM student WHERE sid={$userId}";
       if(mysqli_query($databaseConn,$deleteQuery)){
          mysqli_close($databaseConn);
         header("Location: http://localhost/php/crud_html/index.php");
       }else{
        echo "Query Failed !";
       }

  }else{
    echo "NO STUDENT IS SELECTED !";
  }






?>