<?php
  
  if(isset($_POST['saveData'])){

    $studentName=$_POST['sname'];
    $studentAddress=$_POST['saddress'];
    $studentClas=$_POST['class'];
    $studentPhone=$_POST['sphone'];

    $host="localhost";
    $userName="root";
    $password="";
    $dbname="newcrud";
    
    $dbconnection=mysqli_connect($host,$userName,$password,$dbname)or die("Connection failed");
    
    $storeQuery="INSERT INTO student(sname,saddress,sclass,sphone)
    VALUE('{$studentName}','{$studentAddress}','{$studentClas}','{$studentPhone}')";
    
    $result=mysqli_query($dbconnection,$storeQuery) or die("store Query failed");
    
    mysqli_close($dbconnection);
    header("Location: http://localhost/php/crud_html/index.php");

  }else{

      echo "<h2> Data Not Submitted Yet </h2>";
  }


?>