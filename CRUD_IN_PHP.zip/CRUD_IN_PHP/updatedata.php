<?php
  if(isset($_POST['saveData'])){
          $studentID=$_POST['sid'];
          $studentName=$_POST['sname'];
          $studentAddress=$_POST['saddress'];
          $studentClass=$_POST['class'];
          $studentPhone=$_POST['sphone'];

    $conn=mysqli_connect("localhost","root","","newcrud") or die("connction failed");
    $delete="DELETE FROM student where sid=$studentID";
    if(mysqli_query($conn,$delete)){
         
        $storeQuery="INSERT INTO student(sname,saddress,sclass,sphone)
        VALUE('{$studentName}','{$studentAddress}','{$studentClass}','{$studentPhone}')";
        
        $result=mysqli_query($conn,$storeQuery) or die("store Query failed");
          
        if($result){
                header("Location: http://localhost/php/crud_html/index.php");
        }
    }

  }

?>